# My Reinforcement Learning Library

## Install

	pip install myrl
